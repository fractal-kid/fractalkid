This is a placeholder for the 'exit protocol'.
They are watching.
